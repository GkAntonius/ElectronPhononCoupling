from __future__ import print_function

from copy import copy

import numpy as np
from numpy import zeros, ones, einsum

from .constants import tol6, tol8, tol12, Ha2eV, kb_HaK

from .qptanalyzer import QptAnalyzer
from . import EigFile, Eigr2dFile, FanFile, DdbFile, GkkFile, GsrFile

from .mpi import comm, size, rank, master_only, mpi_watch, i_am_master

__author__ = "Gabriel Antonius"

__all__ = ['QptPhononSeAnalyzer']


class QptPhononSeAnalyzer(QptAnalyzer):

    _nband = 0
    verbose = False

    def __init__(self,
                 DDB_fname=None,
                 GKK_fname=None,
                 k_eig_fname=None,
                 kq_eig_fname=None,
                 k_GSR_fname=None,
                 kq_GSR_fname=None,
                 smearing=0.00367,
                 nband=None,
                 verbose=False,
                 **kwargs):

        # Options
        self.verbose = verbose

        self.ddb = DdbFile(DDB_fname, read=False, asr=kwargs.get('asr', True))
        self.gkk = GkkFile(GKK_fname, read=False)
        self.eig_k = EigFile(k_eig_fname, read=False)
        self.eig_kq = EigFile(kq_eig_fname, read=False)
        self.gsr_k = GsrFile(k_GSR_fname, read=False)
        self.gsr_kq = GsrFile(kq_GSR_fname, read=False)

        # Parameters
        self.smearing = smearing
        self.nband = nband

        # Read the files and broadcast the data
        self.read_files()
        
        # Split the workload between workers
        self.distribute_workload()

        if not self.nband:
            self.nband = min(self.eig_k.nband, self.eig_kq.nband,
                             self.gsr_k.nband, self.gsr_kq.nband,
                             self.gkk.nband)

    @property
    def has_active(self):
        return True

    @mpi_watch
    def read_files(self):
        """Read all nc files that are not specifically related to q=0."""
        for f in (self.ddb, self.gkk, self.eig_k, self.eig_kq,
                  self.gsr_k, self.gsr_kq):

            if f.fname:

                # Master reads the file
                if i_am_master:
                    f.read_nc()

                # Broadcast data to all workers
                f.broadcast()

        self.ddb.compute_dynmat()

    @property
    def nsppol(self):
        return self.gkk.nsppol

    @property
    def nkpt(self):
        return self.gkk.nkpt

    @property
    def nband(self):
        return self._nband

    @nband.setter
    def nband(self, value):
        self._nband = value

    @mpi_watch
    def distribute_workload(self):
        """Distribute the k-points indicies to be treated by each worker."""

        max_nkpt_per_worker = self.nkpt // size + min(self.nkpt % size, 1)
        n_active_workers = self.nkpt // (max_nkpt_per_worker
                                    + min(self.nkpt % max_nkpt_per_worker, 1))

        self.my_ikpts = list()

        for i in range(max_nkpt_per_worker):

            ikpt = rank * max_nkpt_per_worker + i

            if ikpt >= self.nkpt:
                break

            self.my_ikpts.append(ikpt)

    @property
    def active_worker(self):
        return bool(self.my_ikpts)

    def get_active_ranks(self):
        """Get the ranks of all active workers."""
        max_nkpt_per_worker = self.nkpt // size + min(self.nkpt % size, 1)
        n_active_workers = self.nkpt // max_nkpt_per_worker + min(self.nkpt % max_nkpt_per_worker, 1)
        return np.arange(n_active_workers)

    def get_occ_k(self):
        return self.gsr_k.occ[0,:,:]

    def get_occ_kq(self):
        return self.gsr_kq.occ[0,:,:]

    def get_gkk2(self):
        """
        Compute the squared gkk elements.

        Returns:
            gkk2[nkpt, nband, nband, nmode]
        """

        if not self.has_active:
            raise Exception('You should provide GKK files or FAN files '
                            'to compute active space contribution.')

        # Get reduced displacement (scaled with frequency)
        displ_red_FAN2, displ_red_DDW2 = self.ddb.get_reduced_displ_squared()

        # gkk2 in atomic and cartesian basis
        gkk2_atcart = self.gkk.get_gkk_squared()

        # nkpt, nband, nband, nmode
        gkk2 = einsum('kniajbm,oabij->knmo', gkk2_atcart, displ_red_FAN2)

        return gkk2
    
    def get_kpt_gkk2(self, ikpt):
        """
        Compute the squared gkk elements.

        Returns:
            gkk2[nband, nband, nmode]
        """

        if not self.has_active:
            raise Exception('You should provide GKK files or FAN files '
                            'to compute active space contribution.')

        # Get reduced displacement (scaled with frequency)
        displ_red_FAN2, displ_red_DDW2 = self.ddb.get_reduced_displ_squared()

        # gkk2 in atomic and cartesian basis
        gkk2_atcart = self.gkk.get_kpt_gkk_squared(ikpt)

        # nkpt, nband, nband, nmode
        gkk2 = einsum('niajbm,oabij->nmo', gkk2_atcart, displ_red_FAN2)

        return gkk2
    
    def get_static_phonon_se(self):
        """
        Compute the real part of the phonon self-energy
        evaluated at the phonon frequencies.
        """
        return self.sum_kpt_function('get_kpt_static_phonon_se')

    def get_kpt_static_phonon_se(self, ikpt):
        """
        Compute one k-point contribution to the real part
        of the phonon self-energy evaluated at the phonon frequencies.
        """

        nband = self.nband
        nmode = self.nmode

        omega = self.ddb.omega

        # nband, mband, nmode
        gkk2_nm = np.real(self.get_kpt_gkk2(ikpt)[:nband,:nband,:])

        occ_n = self.gsr_k.occ[0,ikpt,:nband]
        eig_n = self.eig_k.EIG[0,ikpt,:nband].real
        occ_m = self.gsr_kq.occ[0,ikpt,:nband]
        eig_m = self.eig_kq.EIG[0,ikpt,:nband].real

        # nband, mband
        delta_E = (einsum('n,m->nm', eig_n, ones(nband))
                    - einsum('m,n->nm', eig_m, ones(nband)))

        # nband, mband, nmode
        delta_E = einsum('nm,o->nmo', delta_E, ones(nmode)) - 1j * self.smearing
    
        # nband, mband, nmode
        delta_E_omega = (delta_E
                        - einsum('nm,o->nmo', ones((nband,nband)), omega))

        # nband, mband, nmode
        delta_f = (einsum('n,mo->nmo', occ_n, ones((nband,nmode)))
                    - einsum('m,no->nmo', occ_m, ones((nband,nmode)))) 
    
        # nkpt, nband, mband, nmode
        delta_chi = np.real(delta_f * (1. / delta_E_omega - 1. / delta_E))
        
        # nmode
        Pi_k = einsum('nmo,nmo->o', gkk2_nm, delta_chi)

        return Pi_k

    def sum_kpt_function_me(self, func_name, *args, **kwargs):
        """Call a certain function or each k-points of this worker and sum the result."""
        if not self.active_worker:
            return None

        ikpt = self.my_ikpts[0]

        if self.verbose:
            print("K-point: {:>5d} / {} ".format(ikpt+1, self.nkpt))

        k0 = getattr(self, func_name)(ikpt, *args, **kwargs)
        total = copy(k0)

        if len(self.my_ikpts) == 1:
            return total

        for ikpt in self.my_ikpts[1:]:

            if self.verbose:
                print("K-point: {:>5d} / {} ".format(ikpt+1, self.nkpt))

            kpt = getattr(self, func_name)(ikpt, *args, **kwargs)
            total += kpt

        return total

    @mpi_watch
    def sum_kpt_function(self, func_name, *args, **kwargs):
        """Call a certain function or each k-points and sum the result."""

        partial_sum = self.sum_kpt_function_me(func_name, *args, **kwargs)

        if i_am_master:
            total = partial_sum
            active_ranks = self.get_active_ranks()
            if len(active_ranks) > 1:
                for irank in active_ranks[1:]:
                    partial_sum = comm.recv(source=irank, tag=irank)
                    total += partial_sum

        elif self.active_worker:
            comm.send(partial_sum, dest=0, tag=rank)
            return

        else:
            return

        # Now I could broadcast the total result to all workers
        # but right now there is no need to.

        return total

