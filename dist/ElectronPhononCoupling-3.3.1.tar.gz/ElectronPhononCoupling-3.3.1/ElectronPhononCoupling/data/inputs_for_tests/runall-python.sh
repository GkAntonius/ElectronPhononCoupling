#!/bin/sh
python t11.py
python t12.py
python t13.py
python t14.py
python t21.py
python t22.py
python t23.py
python t24.py
python t31.py
python t32.py
python t33.py
python t34.py
