#!/bin/sh
pp-temperature < test11.in
pp-temperature < test12.in
pp-temperature < test13.in
pp-temperature < test14.in
pp-temperature < test21.in
pp-temperature < test22.in
pp-temperature < test23.in
pp-temperature < test24.in
pp-temperature < test31.in
pp-temperature < test32.in
pp-temperature < test33.in
pp-temperature < test34.in
pp-temperature < test41.in
pp-temperature < test54.in
