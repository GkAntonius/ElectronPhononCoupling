#!/bin/sh
electron-phonon-coupling < t11.in
electron-phonon-coupling < t12.in
electron-phonon-coupling < t13.in
electron-phonon-coupling < t14.in
electron-phonon-coupling < t21.in
electron-phonon-coupling < t22.in
electron-phonon-coupling < t23.in
electron-phonon-coupling < t24.in
electron-phonon-coupling < t31.in
electron-phonon-coupling < t32.in
electron-phonon-coupling < t33.in
electron-phonon-coupling < t34.in
