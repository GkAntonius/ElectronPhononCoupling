#!/bin/sh
pp-temperature < t11.in
pp-temperature < t12.in
pp-temperature < t13.in
pp-temperature < t14.in
pp-temperature < t21.in
pp-temperature < t22.in
pp-temperature < t23.in
pp-temperature < t24.in
pp-temperature < t31.in
pp-temperature < t32.in
pp-temperature < t33.in
pp-temperature < t34.in
pp-temperature < t41.in
